var app = require('express')(),
	server = require('http').createServer(app),
	io = require('socket.io').listen(server),
	ent = require('ent'),
	todolist = [];

app.get('/todo', function(req, res){
	res.render('todo.ejs', {todolist: todolist});
})
.use(function(req, res, next){
	res.redirect('/todo');
});

io.sockets.on('connection', function(socket){

	socket.on('addtodo', function(todo){
		todoEncoded = ent.encode(todo);
		todolist.push(todoEncoded);
		socket.emit('updateToDoList', todolist);
		socket.broadcast.emit('updateToDoList', todolist);
	});

	socket.on('removetodo', function(todoid){
		// On vérifie que l'index transmit soit bien un entier qui pourrait correspondre à une entrée du tableau
		todoid = parseInt(todoid);
		if (todoid >= 0 && todoid < todolist.length) {
			todolist.splice(todoid, 1);
			socket.emit('updateToDoList', todolist);
			socket.broadcast.emit('updateToDoList', todolist);
		}
	});

});

server.listen(8080);